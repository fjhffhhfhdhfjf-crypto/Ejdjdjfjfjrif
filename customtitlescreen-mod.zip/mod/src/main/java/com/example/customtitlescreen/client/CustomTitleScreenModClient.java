package com.example.customtitlescreen.client;

import net.fabricmc.api.ClientModInitializer;

public class CustomTitleScreenModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // The actual work happens in MinecraftClientMixin, which swaps every
        // vanilla TitleScreen for SeasonTimeTitleScreen. Nothing else to do here.
    }
}
