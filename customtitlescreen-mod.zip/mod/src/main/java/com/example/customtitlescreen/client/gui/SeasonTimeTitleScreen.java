package com.example.customtitlescreen.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Custom main-menu screen: procedural sky/ground background that reacts to a
 * selected Season + time-of-day, animated seasonal particles, and a small
 * control panel (top-right) with season tabs + a draggable time slider.
 *
 * NOTE ON VANILLA CLASS NAMES: MultiplayerScreen / SelectWorldScreen /
 * OptionsScreen constructor signatures occasionally change between minor
 * Minecraft versions. These match 1.21.x Mojang-mapped names; if your Yarn
 * build complains, check the equivalent class/constructor in your mappings
 * and adjust the four button actions in initButtons() below.
 */
public class SeasonTimeTitleScreen extends Screen {

    public enum Season {
        SPRING("ВЕСНА", 0x9BE15D, 0x6FB7E8),
        SUMMER("ЛЕТО", 0x4CAF50, 0x4FA8E0),
        AUTUMN("ОСЕНЬ", 0xD98A2B, 0x6E86A0),
        WINTER("ЗИМА", 0xE8F0FF, 0x7C93B5);

        final String label;
        final int groundColor;
        final int skyAccent;

        Season(String label, int groundColor, int skyAccent) {
            this.label = label;
            this.groundColor = groundColor;
            this.skyAccent = skyAccent;
        }
    }

    private static final String TITLE = "Fabric 1.21.4 — сезонное меню";
    private static final String SUBTITLE = "Сборка собрана и прогрета.";

    // top-right panel geometry
    private static final int PANEL_W = 170;
    private static final int PANEL_H = 70;
    private int panelX, panelY;
    private static final int SLIDER_H = 10;

    private Season currentSeason = Season.AUTUMN;
    private float timeHours = 20.5f; // 0-24
    private boolean draggingSlider = false;

    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();
    private long lastTickNanos = -1;

    private final List<ButtonWidget> seasonTabs = new ArrayList<>();

    protected SeasonTimeTitleScreen() {
        super(Text.literal("Custom Title Screen"));
    }

    @Override
    protected void init() {
        this.panelX = this.width - PANEL_W - 12;
        this.panelY = 10;

        spawnParticles();
        initSeasonTabs();
        initMenuButtons();
    }

    // ---------------------------------------------------------- UI setup

    private void initSeasonTabs() {
        seasonTabs.clear();
        Season[] seasons = Season.values();
        int tabW = PANEL_W / seasons.length;
        for (int i = 0; i < seasons.length; i++) {
            Season s = seasons[i];
            ButtonWidget tab = ButtonWidget.builder(seasonTabLabel(s), btn -> {
                currentSeason = s;
                spawnParticles();
                refreshSeasonTabLabels();
            }).dimensions(panelX + i * tabW, panelY, tabW, 16).build();
            seasonTabs.add(tab);
            addDrawableChild(tab);
        }
    }

    private void refreshSeasonTabLabels() {
        Season[] seasons = Season.values();
        for (int i = 0; i < seasons.length; i++) {
            seasonTabs.get(i).setMessage(seasonTabLabel(seasons[i]));
        }
    }

    private Text seasonTabLabel(Season s) {
        return Text.literal(s == currentSeason ? "[" + s.label + "]" : s.label);
    }

    private void initMenuButtons() {
        int buttonW = 150;
        int x = 16;
        int y = this.height / 2 - 10;
        int spacing = 22;

        addDrawableChild(ButtonWidget.builder(Text.literal("Сетевая игра"), btn -> {
            if (this.client != null) this.client.setScreen(new MultiplayerScreen(this));
        }).dimensions(x, y, buttonW, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Одиночная игра"), btn -> {
            if (this.client != null) this.client.setScreen(new SelectWorldScreen(this));
        }).dimensions(x, y + spacing, buttonW, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Сменить аккаунт"), btn -> {
            // Account switching normally lives in the launcher, not the game itself.
            // Hook your own logic here if you have an auth flow to open.
        }).dimensions(x, y + spacing * 2, buttonW, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Настройки"), btn -> {
            if (this.client != null) this.client.setScreen(new OptionsScreen(this, this.client.options));
        }).dimensions(x, y + spacing * 3 + 6, buttonW / 2 - 3, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Выйти из игры"), btn -> {
            if (this.client != null) this.client.scheduleStop();
        }).dimensions(x + buttonW / 2 + 3, y + spacing * 3 + 6, buttonW / 2 - 3, 20).build());
    }

    // ---------------------------------------------------------- particles

    private void spawnParticles() {
        particles.clear();
        int count = switch (currentSeason) {
            case WINTER -> 90;
            case AUTUMN -> 70;
            case SPRING -> 60;
            case SUMMER -> 30;
        };
        for (int i = 0; i < count; i++) {
            particles.add(randomParticle(random.nextInt(Math.max(this.height, 200))));
        }
    }

    private Particle randomParticle(int startY) {
        float x = random.nextFloat() * (this.width == 0 ? 1000 : this.width);
        float speed = 10f + random.nextFloat() * 20f;
        float size = 1.5f + random.nextFloat() * 2.0f;
        float drift = (random.nextFloat() - 0.5f) * 6f;
        return new Particle(x, startY, speed, size, drift);
    }

    private void tickParticles(float deltaSeconds) {
        for (int i = 0; i < particles.size(); i++) {
            Particle p = particles.get(i);
            p.y += p.speed * deltaSeconds;
            p.x += p.drift * deltaSeconds;
            if (p.y > this.height) {
                particles.set(i, randomParticle(-4));
            }
        }
    }

    private int particleColor() {
        return switch (currentSeason) {
            case WINTER -> 0xFFFFFFFF; // snow
            case AUTUMN -> 0xFFD98A2B; // falling leaves
            case SPRING -> 0xFFF7C6DE; // petals
            case SUMMER -> 0xFFFFF6B0; // pollen/dust
        };
    }

    // ---------------------------------------------------------- time helpers

    private String timeLabel() {
        int h = ((int) timeHours) % 24;
        if (h >= 5 && h < 11) return "Утро";
        if (h >= 11 && h < 17) return "День";
        if (h >= 17 && h < 21) return "Вечер";
        return "Ночь";
    }

    private boolean isDaytime() {
        int h = ((int) timeHours) % 24;
        return h >= 6 && h < 18;
    }

    /** 0 = full night, 1 = full day, smooth around dawn/dusk */
    private float dayFactor() {
        float h = timeHours % 24f;
        float dawn = smooth(h, 4f, 7f);
        float dusk = 1f - smooth(h, 18f, 21f);
        return Math.max(0f, Math.min(dawn, dusk));
    }

    private float smooth(float h, float start, float end) {
        if (h <= start) return 0f;
        if (h >= end) return 1f;
        return (h - start) / (end - start);
    }

    private int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------------------------------------------------------- render

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float deltaSeconds = lastTickNanos < 0 ? 0f : (now - lastTickNanos) / 1_000_000_000f;
        lastTickNanos = now;
        tickParticles(deltaSeconds);

        drawSky(context);
        drawGroundSilhouette(context);
        drawParticles(context);
        drawHeaderAndAccount(context);
        drawSeasonTimePanel(context, mouseX, mouseY);

        super.render(context, mouseX, mouseY, delta);

        drawTitleText(context);
        drawFooter(context);
    }

    private void drawSky(DrawContext context) {
        float day = dayFactor();
        int nightTop = 0xFF0B1533, nightBottom = 0xFF1B2A4A;
        int dayTop = 0xFF7EC8F2, dayBottom = 0xFFBFE6F5;

        int top = lerpColor(nightTop, dayTop, day);
        int bottom = lerpColor(nightBottom, dayBottom, day);
        // subtle seasonal tint on the sky bottom, blended in only during daytime
        bottom = lerpColor(bottom, currentSeason.skyAccent | 0xFF000000, 0.25f * day);

        context.fillGradient(0, 0, this.width, this.height, top, bottom);
    }

    private void drawGroundSilhouette(DrawContext context) {
        int groundTop = this.height - 90;
        float day = dayFactor();
        int groundColor = lerpColor(0xFF05070F, currentSeason.groundColor | 0xFF000000, 0.35f + 0.4f * day);
        // simple jagged silhouette using a handful of stacked rectangles
        int step = this.width / 10;
        for (int i = 0; i < 10; i++) {
            int hOffset = (int) (Math.sin(i * 1.7f) * 14f);
            context.fill(i * step, groundTop + hOffset, (i + 1) * step + 1, this.height, groundColor);
        }
    }

    private void drawParticles(DrawContext context) {
        int color = particleColor();
        for (Particle p : particles) {
            int s = Math.max(1, Math.round(p.size));
            context.fill((int) p.x, (int) p.y, (int) p.x + s, (int) p.y + s, color);
        }
    }

    private void drawHeaderAndAccount(DrawContext context) {
        String name = this.client != null ? this.client.getSession().getUsername() : "Player";
        context.drawTextWithShadow(this.textRenderer, Text.literal(name), 14, 12, 0xFFFFFF);
    }

    private void drawTitleText(DrawContext context) {
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(TITLE), this.width / 2, 16, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer, Text.literal(SUBTITLE), 14, this.height / 2 - 34, 0xC8C8C8);
    }

    private void drawFooter(DrawContext context) {
        context.drawTextWithShadow(this.textRenderer, Text.literal("CustomTitleScreen 1.0.0  ·  Minecraft 1.21.4"), 6, this.height - 12, 0x808080);
    }

    private void drawSeasonTimePanel(DrawContext context, int mouseX, int mouseY) {
        // panel backdrop
        context.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, 0xAA10131C);

        int clockY = panelY + 20;
        context.drawTextWithShadow(this.textRenderer,
                Text.literal(String.format("%02d:%02d  %s", (int) timeHours % 24, (int) ((timeHours % 1) * 60), timeLabel())),
                panelX + 6, clockY, 0xFFFFFF);

        // sun/moon indicator
        int iconX = panelX + PANEL_W - 16, iconY = clockY;
        int iconColor = isDaytime() ? 0xFFF6C453 : 0xFFB9C6E0;
        context.fill(iconX, iconY, iconX + 8, iconY + 8, iconColor);

        drawTimeSlider(context, panelY + PANEL_H - SLIDER_H - 6);
    }

    private int sliderTrackX() {
        return panelX + 6;
    }

    private int sliderTrackW() {
        return PANEL_W - 12;
    }

    private void drawTimeSlider(DrawContext context, int trackY) {
        int trackX = sliderTrackX();
        int trackW = sliderTrackW();

        // gradient stops across the 24h cycle: night -> dawn -> day -> dusk -> night
        int night = 0xFF1B2A4A, dawn = 0xFFF2A65A, day = 0xFF7EC8F2, dusk = 0xFFDA6A45;
        for (int px = 0; px < trackW; px++) {
            float h = (px / (float) trackW) * 24f;
            int color;
            if (h < 5) color = night;
            else if (h < 7) color = lerpColor(night, dawn, (h - 5) / 2f);
            else if (h < 11) color = lerpColor(dawn, day, (h - 7) / 4f);
            else if (h < 17) color = day;
            else if (h < 19) color = lerpColor(day, dusk, (h - 17) / 2f);
            else if (h < 21) color = lerpColor(dusk, night, (h - 19) / 2f);
            else color = night;
            context.fill(trackX + px, trackY, trackX + px + 1, trackY + SLIDER_H, color);
        }

        // handle
        int handleX = trackX + (int) ((timeHours / 24f) * trackW);
        context.fill(handleX - 2, trackY - 2, handleX + 3, trackY + SLIDER_H + 2, 0xFFFFFFFF);
    }

    // ---------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isOverSlider(mouseX, mouseY)) {
            draggingSlider = true;
            updateSliderFromMouse(mouseX);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSlider) {
            updateSliderFromMouse(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingSlider = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private boolean isOverSlider(double mouseX, double mouseY) {
        int trackY = panelY + PANEL_H - SLIDER_H - 6;
        return mouseX >= sliderTrackX() - 4 && mouseX <= sliderTrackX() + sliderTrackW() + 4
                && mouseY >= trackY - 6 && mouseY <= trackY + SLIDER_H + 6;
    }

    private void updateSliderFromMouse(double mouseX) {
        float t = (float) ((mouseX - sliderTrackX()) / (double) sliderTrackW());
        timeHours = Math.max(0f, Math.min(24f, t * 24f));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class Particle {
        float x, y, speed, size, drift;
        Particle(float x, float y, float speed, float size, float drift) {
            this.x = x;
            this.y = y;
            this.speed = speed;
            this.size = size;
            this.drift = drift;
        }
    }
}
